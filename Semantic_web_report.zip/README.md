# CineGraph report for Overleaf

Upload the ZIP project with Overleaf: New Project > Upload Project.
Main file: `main.tex`. Suggested compiler: pdfLaTeX with BibTeX.

The report follows this outline:
1. Introduction
   1.1 Ontology Definition
2. Data Collection and Transformation
   2.1 Data Collection
   2.2 Data Transformation
   2.3 Audit Crawled Data
3. Linking Data to External Datasets
4. Publishing SPARQL endpoint
5. Conclusion

Section 2.3 keeps only the SHACL-based data-quality check. Other audit and
evaluation sections have been removed from the report.

The final saved RDF graph contains 645,850 triples and conforms to the production
SHACL constraints with zero violations. The source package keeps the production
SHACL evidence required by the report. No API key or `.env` file is included.
